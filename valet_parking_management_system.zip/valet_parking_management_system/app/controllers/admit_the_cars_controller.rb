class AdmitTheCarsController < ApplicationController
	def admit_the_cars
		if @admit_the_car = AdmitTheCarToSpot.call(params[:car_size], params[:license_plat_number])
			render json: {data: @admit_the_car}
		end
	end

	def exit_the_cars
		if @exit_the_car = ExitTheCarFromSpot.call(params[:license_plat_number])
			render json: {dta: @exit_the_car}
		end
	end
end
