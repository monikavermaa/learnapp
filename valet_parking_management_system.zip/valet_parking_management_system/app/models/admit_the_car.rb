class AdmitTheCar < ApplicationRecord
  enum car_size: { small: 'small', medium: 'medium', large: 'large' }
  belongs_to :parking_spot
  validates :license_plat_number, uniqueness: true, presence: true
  validates :car_size, presence: true
end
