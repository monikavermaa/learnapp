class ParkingSpot < ApplicationRecord
  enum car_size: { small: 'small', medium: 'medium', large: 'large' }
  has_many :admit_the_cars, dependent: :destroy
  scope :small_size, -> {where(car_size: "small")}
  scope :medium_size, -> {where(car_size: "medium")}
  scope :large_size, -> {where(car_size: "large")}
end
