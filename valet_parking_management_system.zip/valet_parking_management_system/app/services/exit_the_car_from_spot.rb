module ExitTheCarFromSpot
  class << self
    def call(license_plat_number)
      exit_the_car(license_plat_number)
    end 
    
    private

    def exit_the_car(license_plat_number)
       admited_car = AdmitTheCar.find_by_license_plat_number(license_plat_number)
      if admited_car.present? && admited_car.parking_spot.present?
        admited_car.parking_spot.number_of_car += 1 
        admited_car.parking_spot.save
        admited_car.delete
        return "success license plat number: #{admited_car.license_plat_number} available parking spot small: #{ParkingSpot.small_size.first.number_of_car},  medium: #{ParkingSpot.medium_size.first.number_of_car}, large: #{ParkingSpot.large_size.first.number_of_car}"
      else
        return "this car is not park in this garage"
      end 
     end 
  end
end

