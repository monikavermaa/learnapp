module ShuffleTheCar
  class << self
    def call(car_size)
      shuffle_the_car(car_size)
    end

    private

    def shuffle_the_car(car_size)
      large_parking_spot = ParkingSpot.large_size
      small_parking_spot = ParkingSpot.small_size
      medium_parking_spot = ParkingSpot.medium_size
      parking_spot = ParkingSpot.where(car_size: car_size)
      if parking_spot == large_parking_spot
        suffle_with_small_car(parking_spot, small_parking_spot)
        suffle_large_car_with_medium_car(parking_spot, medium_parking_spot)
      else
        suffle_with_small_car(parking_spot, small_parking_spot)  
      end
      return ParkingSpot.where(car_size: car_size)
    end

    def suffle_with_small_car(parking_spot, small_parking_spot)
      if small_parking_spot.first.number_of_car >= 1
        spot = parking_spot.first.admit_the_cars.where(car_size: "small").last
        if spot.present?
          spot.update(:parking_spot_id => small_parking_spot.first.id)
          small_parking_spot.first.number_of_car -= 1
          small_parking_spot.first.save
          parking_spot.first.number_of_car +=1
          parking_spot.first.save
        end
      end
    end

    def suffle_large_car_with_medium_car(parking_spot, medium_parking_spot)
      if parking_spot.first.number_of_car < 1 && (medium_parking_spot.first.number_of_car >= 1)
        spot = parking_spot.first.admit_the_cars.where(car_size: "medium").last
        if spot.present?
          spot.update(:parking_spot_id => medium_parking_spot.first.id)
          medium_parking_spot.first.number_of_car -=1
          medium_parking_spot.first.save
          parking_spot.first.number_of_car +=1
          parking_spot.first.save
        end
      end
    end
  end
end