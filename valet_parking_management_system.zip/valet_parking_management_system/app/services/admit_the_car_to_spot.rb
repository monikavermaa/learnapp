module AdmitTheCarToSpot
  class << self
    def call(car_size, license_plat_number)
      check_free_space(car_size, license_plat_number)
    end

    private

    def check_free_space(car_size, license_plat_number)
      if car_size.present? &&  (["small", "medium", "large"].include? car_size)
        @parking_spot = ""
        s = ParkingSpot.small_size if (car_size == "small")
        m = ParkingSpot.medium_size if ((car_size == "small") || (car_size == "medium"))
        l = ParkingSpot.large_size
        if s.present? && (s.first.number_of_car > 0)
          @parking_spot = s
        elsif m.present? && (m.first.number_of_car > 0) && @parking_spot.blank?
          @parking_spot = m
        elsif l.present? && (l.first.number_of_car > 0) && @parking_spot.blank?
          @parking_spot = l
        end 
        if ParkingSpot.all.sum(:number_of_car) > 0
          @parking_spot = ShuffleTheCar.call(car_size) unless (@parking_spot.present? && (@parking_spot.first.number_of_car > 0))
        else
          return "no space for parking" unless (@parking_spot.first.present? && @parking_spot.first.number_of_car >= 0)
        end 
        admit_the_car(car_size, license_plat_number, @parking_spot)
      else
        return "car size should present and should be small, medium or large"
      end    
    end

    def admit_the_car(car_size, license_plat_number, parking_spot)
      return "validation failed, license plat number already exists" if AdmitTheCar.find_by_license_plat_number(license_plat_number).present?
      return  "no space for parking"  unless parking_spot.first.number_of_car > 0
      return false unless parking_spot.first.admit_the_cars.create(car_size: car_size, license_plat_number: license_plat_number, parking_spot_id: parking_spot.first.id)
      parking_spot.first.number_of_car -= 1
      return false unless parking_spot.first.save
      return "success car #{parking_spot.first.admit_the_cars.last.car_size} is park in #{parking_spot.first.car_size} parking spot, available parking spot small: #{ParkingSpot.small_size.first.number_of_car},  medium: #{ParkingSpot.medium_size.first.number_of_car}, large: #{ParkingSpot.large_size.first.number_of_car}"
    end
  end
end