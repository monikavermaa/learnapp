Rails.application.routes.draw do
  post "admit_the_car" ,to: "admit_the_cars#admit_the_cars"
  post "exit_the_car",to: "admit_the_cars#exit_the_cars"
end
