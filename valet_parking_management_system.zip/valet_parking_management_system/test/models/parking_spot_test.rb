require "test_helper"

class ParkingSpotTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
