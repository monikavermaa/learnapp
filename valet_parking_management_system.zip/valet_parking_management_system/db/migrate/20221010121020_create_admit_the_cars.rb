class CreateAdmitTheCars < ActiveRecord::Migration[6.1]
  def change
    create_table :admit_the_cars do |t|
      t.string :car_size
      t.string :license_plat_number
      t.integer :parking_spot_id
      t.timestamps
    end
  end
end
