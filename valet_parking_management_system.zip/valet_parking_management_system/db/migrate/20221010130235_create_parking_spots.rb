class CreateParkingSpots < ActiveRecord::Migration[6.1]
  def change
    create_table :parking_spots do |t|
      t.string :car_size
      t.integer :number_of_car
      t.timestamps
    end
  end
end
