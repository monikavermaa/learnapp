# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

1. bundle
2. rails db:create
3. rails db:migrate
4. rails db:seed
5. rake shuffle_car(need to run when want to suffle the car)

* Ruby version
2.6.0

* Rails Version
6.0.1

* Postman Collection
  https://www.getpostman.com/collections/352edcd841d650cc622f

  there are two API
  1.admit the car
  2.exit the car

* Seed 
need to run rails db:seed for create parking spot

* rake
need to run rake task by command 
  rake shuffle_car
  created rake task for suffle the car